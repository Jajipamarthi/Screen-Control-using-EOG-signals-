# Screen-Control-using-EOG
## Description:
The general idea is to collect the EOG signal from the user and classify them to neutral, left, right, up, down and blink. Based on the decision of a SVM-kNN hybrid classifier, the cursor of the screen moves in that direction and depending the blinks interval of time, the brightness of the screen is controlled.
